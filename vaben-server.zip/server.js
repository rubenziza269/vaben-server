const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const cors = require('cors');
const app = express();

app.use(cors({ origin: '*' }));
app.use(express.json());

// ── Health check ──
app.get('/', (req, res) => res.send('Vaben server running ✅'));

// ── Étape 1 : Créer un PaymentIntent (argent bloqué en séquestre) ──
app.post('/create-payment', async (req, res) => {
  try {
    const { amount } = req.body;
    // amount = montant en agorot (₪100 = 10000 agorot)
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount),
      currency: 'ils',
      payment_method_types: ['card'],
      capture_method: 'automatic',
      metadata: { platform: 'vaben' }
    });
    res.json({ clientSecret: paymentIntent.client_secret });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ── Étape 2 : Transférer au vendeur après validation réception ──
app.post('/transfer-to-seller', async (req, res) => {
  try {
    const { amount, sellerStripeId, paymentIntentId } = req.body;
    const commission = Math.round(amount * 0.005); // 0.5% plateforme
    const sellerAmount = amount - commission;

    const transfer = await stripe.transfers.create({
      amount: sellerAmount,
      currency: 'ils',
      destination: sellerStripeId,
      source_transaction: paymentIntentId,
    });
    res.json({ success: true, transfer });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Vaben server on port ${PORT}`));
